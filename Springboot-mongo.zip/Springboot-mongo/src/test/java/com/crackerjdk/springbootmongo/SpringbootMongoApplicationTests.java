package com.crackerjdk.springbootmongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMongoApplicationTests {

    @Test
    void contextLoads() {
    }

}
